Austroraptor verified web texture package

pattern_1.webp = T_Austroraptor_Adult_Pattern_1.png, purple Flank/Markings transitions normalized offline
pattern_2.webp = T_Austroraptor_Adult_Pattern_2.png, purple Flank/Markings transitions normalized offline
pattern_3.webp = T_Austroraptor_Adult_Pattern_3.png, purple Flank/Markings transitions normalized offline
pattern_4.webp = T_Austroraptor_Adult_Pattern_Heron_M.png, normalized to the exact website recolor palette
mask_tmc.webp = T_Austroraptor_M.png
normal.webp = T_Austroraptor_Adult_N.png

All WebP files use lossless encoding. Pattern pixels are intentionally preprocessed as documented below; normal and TMC retain their original pixels and channels. Patterns and TMC are 2048x2048; the normal map is 4096x4096.
The exported asset folder contains four adult pattern textures. The game DataTable registers patterns 1-3; pattern 4 is the additional Heron resource. Hatchling and juvenile maps are growth-stage patterns, not additional adult patterns.

Patterns 1, 2 and 3 use ordered 8x8 dithering for source pixels located between Flank and Markings. A 50/50 source pixel becomes an approximately equal spatial distribution of the two exact canonical colors. Pattern 4 was already normalized to canonical colors. This keeps every rewritten pixel inside the existing replacement ranges and requires no extra runtime blending or additional fragment-shader work.

Canonical pattern recolor centers (normalized 0..1):
male       = { r: 1, g: 0, b: 0 }
flank      = { r: 0, g: 1/255, b: 245/255 }      // RGB(0, 1, 245)
markings   = { r: 1, g: 0, b: 1 }
detail1    = { r: 1, g: 1, b: 0 }
body       = { r: 0, g: 1, b: 241/255 }          // RGB(0, 255, 241)
underbelly = { r: 0, g: 1, b: 0 }

Squared RGB-distance threshold = (12 / 100) * 3 = 0.36.
Austroraptor DT_SectionsData exposes male, markings, flank, body, and underbelly; detail1 is retained for cross-dinosaur compatibility.

TMC channel semantics shared across dinosaurs:
R = teeth
G = mouth
B = claws
Mixed TMC colors represent simultaneous channel weights, not extra semantic zones.

Three.js color-space requirement for the supplied shader:
pattern.colorSpace = THREE.NoColorSpace
normal.colorSpace = THREE.NoColorSpace
tmcMask.colorSpace = THREE.NoColorSpace

Validation:
- All six WebP files decode correctly and contain no embedded ICC profile.
- normal.webp and mask_tmc.webp are pixel-identical to their exported PNG sources.
- WebP encoding is lossless.
- The ZIP passed an integrity test.
