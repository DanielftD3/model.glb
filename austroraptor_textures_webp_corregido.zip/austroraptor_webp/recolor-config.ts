export const PATTERN_COLORS = {
  male: { r: 1, g: 0, b: 0 },
  // Exact WebP bytes: RGB(0, 1, 245).
  flank: { r: 0, g: 1 / 255, b: 245 / 255 },
  markings: { r: 1, g: 0, b: 1 },
  detail1: { r: 1, g: 1, b: 0 },
  // Exact WebP bytes: RGB(0, 255, 241).
  body: { r: 0, g: 1, b: 241 / 255 },
  underbelly: { r: 0, g: 1, b: 0 },
} as const;

// The shader compares squared RGB distance against this value.
export const COLOR_DISTANCE_THRESHOLD = (12 / 100) * 3;

// TMC is a channel-weight mask, not a discrete-color lookup texture.
export const TMC_CHANNELS = {
  teeth: "r",
  mouth: "g",
  claws: "b",
} as const;

// These are data/lookup textures. With the current shader, load pattern,
// normal and TMC textures with THREE.NoColorSpace to avoid automatic decoding.
export const SKIN_TEXTURE_COLOR_SPACE = "NoColorSpace" as const;
